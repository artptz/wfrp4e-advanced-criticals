# EXPANDED CRITICALS FOR WFRP4E
Expqanded criticals according to the supplement by Josef Tham

## LOG
### Arrows
- All arrows items: how to handle extraction?

**Arm**
- Nicked Wrist: active effect necessary? 
- Perforated Hand: it currently adds Torn Muscle twice when item is removed
- Elbow Wound: Add -10 malus

**Body**
- Internal Bleeding: wanna code the removal of Resistence (Disease)?
- Pierced bladder: missing -10 related to extraction

**Head**
- Brain Damage: generate roll?
- Open Wide: currently removing both teeth and tongue

**Leg**
- Minor Shin Injury: missing
- Shattered Tibia: injury missing, since it depends on healing
- Lower Leg Injury: Injury missing
- Pierced Patellar Injury: Injury missing (same as lower leg injury) 

### Bolts
**Arm**
- Shoulder Wound: drop item missing

**Head**
- Cerebral Haemorrage: should adapt the location of amputated arm and leg to mirror critical side (left arm and left leg for left head critical)
- Neck Wound: Didn't add test, since it can be End or Cool

### Crushing
**Bruised Muscle**
- To do

# v0.2
- Crushing Criticals
- Switch Tables to Compendium items
- Roll Crit macro

# v0.1
- Arrows/Bolts and Bullets Criticals
- RollTables for all groups
 
## Legal Mentions
Author:  \
Module Development: \
Contributors: \
